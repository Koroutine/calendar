<script>
    import {getContext} from 'svelte';
    import {
        cloneDate,
        addDay,
        createEventChunk,
        prepareEventChunks,
        eventIntersects,
        debounce, runReposition, bgEvent
    } from '@event-calendar/core';
    import Day from './Day.svelte';

    let {
        dates: dates,
        resource: resource = undefined
    } = $props();

    let {_events, _iEvents, _queue2, hiddenDays} = getContext('state');

    let chunks = $state([]), bgChunks = $state([]), longChunks = $state([]);

    let start = $state();
    let end = $state();
    let refs = $state([]);

    $effect(() => {
        start = dates[0];
        end = addDay(cloneDate(dates.at(-1)));
    });

    let debounceHandle = $state({});
    function reposition() {
        debounce(() => runReposition(refs, dates), debounceHandle, _queue2);
    }

    $effect(() => {
        chunks = [];
        bgChunks = [];
        for (let event of $_events) {
            if (event.allDay && eventIntersects(event, start, end, resource)) {
                let chunk = createEventChunk(event, start, end);
                if (bgEvent(event.display)) {
                    bgChunks.push(chunk);
                } else {
                    chunks.push(chunk);
                }
            }
        }
        prepareEventChunks(bgChunks, $hiddenDays);
        longChunks = prepareEventChunks(chunks, $hiddenDays);
        // Run reposition only when events get changed
        reposition();
    });

    const iChunks = $derived($_iEvents.map(event => {
        let chunk;
        if (event && event.allDay && eventIntersects(event, start, end, resource)) {
            chunk = createEventChunk(event, start, end);
            prepareEventChunks([chunk], $hiddenDays);
        } else {
            chunk = null;
        }
        return chunk;
    }));
</script>

{#each dates as date, i}
    <Day {date} {chunks} {bgChunks} {longChunks} {iChunks} {resource} bind:this={refs[i]} />
{/each}

<svelte:window on:resize={reposition}/>
